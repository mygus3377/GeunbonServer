#version 430 compatibility

#define WORLD_END
#define PROGRAM_GBUFFERS_VOXELS
#define vsh

#include "/program/gbuffers_all_solid.vsh"