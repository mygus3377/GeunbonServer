#version 400 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_GBUFFERS_SPIDEREYES
#define vsh

#include "/settings.glsl"

#if defined IS_IRIS   // 근본(D): 1.21.1 도 반투명 경로 — 마법 섬광(eyes)이 알파를 잃고 딱 동그란 원반으로 보이던 문제
#include "/program/gbuffers_all_translucent.vsh"
#else
#include "/program/gbuffers_all_solid.vsh"
#endif
