근본 셰이더 (Geunbon Shaders)
================================
근본서버 전용 셰이더팩. 비공개 서버 친구들에게만 배포한다 (Modrinth·CurseForge 등 수익 플랫폼에 올리지 않음).

기반: Photon Shaders by SixthSurge — https://github.com/sixthsurge/photon
라이선스: 동봉된 LICENSE (Photon Shaders License Agreement) 를 따른다.

근본서버 추가 사항
- 좀비물 색감 (채도·톤·필름 노이즈): program/c19_color_grading.fsh 의 geunbon_grade
- 대이동의 밤 핏빛: shaders.properties 의 geunbon_blood
- 빈사 상태 흑백·붉은 맥박
